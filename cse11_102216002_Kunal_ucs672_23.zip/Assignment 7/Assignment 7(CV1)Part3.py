from mtcnn import MTCNN
import cv2

# Load the image (replace path with your masked image)
image_path = "C:/Users/KUNAL/Desktop/notes/DataScience Applications/assignments/Assignment 7/face_mask_1.jpg"
image = cv2.imread(image_path)

# Safety check
if image is None:
    print("❌ Image not found.")
    exit()

# Convert BGR (OpenCV) to RGB (MTCNN expects RGB)
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Initialize MTCNN detector
detector = MTCNN()

# Detect faces
faces = detector.detect_faces(image_rgb)

# Draw rectangles around detected faces
for face in faces:
    x, y, width, height = face['box']
    confidence = face['confidence']
    
    if confidence > 0.9:  # Adjust if needed
        cv2.rectangle(image, (x, y), (x + width, y + height), (0, 255, 0), 2)
        cv2.putText(image, f"Face: {confidence:.2f}", (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

# Show result
cv2.imshow("Masked Face Detection with MTCNN", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
